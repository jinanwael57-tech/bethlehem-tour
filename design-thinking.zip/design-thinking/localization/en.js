export default {
  homeTitle: 'Discover Bethlehem',
  homeDescription: 'Bethlehem, the holy city, full of history, culture, and authentic Palestinian spirit ✨',
  exploreTourism: 'Explore Tourist Places',
  hotels: 'Hotels',
  restaurants: 'Restaurants',
};
