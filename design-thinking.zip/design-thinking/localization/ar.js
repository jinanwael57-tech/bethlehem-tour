export default {
  homeTitle: 'اكتشف بيت لحم',
  homeDescription: 'بيت لحم، المدينة المقدسة، مليانة تاريخ وثقافة وروح فلسطينية أصيلة ✨',
  exploreTourism: 'استكشف الأماكن السياحية',
  hotels: 'استعرض الأوتيلات',
  restaurants: 'استعرض المطاعم',
};
